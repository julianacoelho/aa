<?php
    include 'conexao.php';
    $sql = "CREATE DATABASE IF NOT EXISTS banc_trab;";

    include "tab1.php";
    include "tab2.php";
    include "tab3.php";

    header("Location: principal.php");
?>