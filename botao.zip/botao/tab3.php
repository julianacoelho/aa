<?php

    $criar = mysqli_query($conexao,$sql);

    mysqli_select_db($conexao,"banc_trab");


    $criarTabela = "CREATE TABLE IF NOT EXISTS tb_produto( 
        pro_id int (11) AUTO_INCREMENT not null, 
        pro_nome varchar (80) not null, 
        cli_preco int(10) not null,
        
        PRIMARY KEY(pro_id) )
        ";


    $results = mysqli_query($conexao,$criarTabela);
?>