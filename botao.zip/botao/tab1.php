<?php
    

    $criar = mysqli_query($conexao,$sql);

    mysqli_select_db($conexao,"banc_trab");


    $criarTabela = "CREATE TABLE IF NOT EXISTS tb_cliente( 
        cli_id int (11) AUTO_INCREMENT not null, 
        cli_nome varchar (80) not null, 
        cli_email varchar(80) not null,
        
        PRIMARY KEY(cli_id) )
        ";


    $results = mysqli_query($conexao,$criarTabela);
?>