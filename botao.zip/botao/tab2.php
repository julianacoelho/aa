<?php
   

    $criar = mysqli_query($conexao,$sql);

    mysqli_select_db($conexao,"banc_trab");


    $criarTabela = "CREATE TABLE IF NOT EXISTS tb_vendedor( 
        vend_id int (11) AUTO_INCREMENT not null, 
        vend_nome varchar (80) not null, 
        vend_email varchar(80) not null,
        vend_sessao int(3) not null,
        
        PRIMARY KEY(vend_id) )
        ";


    $results = mysqli_query($conexao,$criarTabela);
    header("Location: principal.php");
?>