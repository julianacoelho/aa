<?php
    
    $user = "root";
    $senha = "";
    $host = "localhost";
    $database = "phpmyadmin";

    $conexao = mysqli_connect($host,$user,$senha,$database);



?>