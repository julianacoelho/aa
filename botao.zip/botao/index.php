<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Botão criar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
   
<body>
    
    <form action="criarBranco.php" method="POST">
        <input type="submit" name="btnEnviar" value="Criar">
    </form>
</body>
</html>