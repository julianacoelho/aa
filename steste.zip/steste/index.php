<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>
	<div class="container">
		<h1>Entrar no Sistema</h1>
		<div class="row">
			<div class="col-md-4">
				
			</div>
			<div class="col-md-4" id="indx">
				<br>
				<br>
				<form method="POST" action="controller/logar.php">
				<input type="text" name="nome" class="form-control" placeholder="Usuario">
				<br>
				<input type="password" name="senha" class="form-control" placeholder="Senha">
				<br>
				<br>
				<input type="submit" name="bt_entrar" class="btn" value="Entrar">
				</form>
			</div>
			<div class="col-md-4">
				
			</div>
		</div>
	</div>

	<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
</body>
</html>