<?php

	include('verificar.php')
?>
<!DOCTYPE html>
<html>
<head>
	<title>Clientes</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h1>Clientes</h1>
				<div  id="pesq" style="height:500px; overflow-y:scroll; overflow-x:hidden;">
					<br>
				  	<?php
				  	include 'conexao.php';

				  	$sql = "SELECT * FROM tb_cliente;";

					$executar = mysqli_query($conexao, $sql);

				while ($linha = $executar->fetch_assoc()) {
					
				   echo "<table class='table table-light'>
				   	<thead>
					    <tr>
					      <th scope='col'>ID</th>
					      <th scope='col'>Nome</th>
					      <th scope='col'>Email</th>
					    </tr>
					 </thead>
					  <tbody>
					    <tr>
					      <th>".$linha['cli_id']."</th>
					      <td>".$linha['cli_nome']."</td>
					      <td>".$linha['cli_email']."</td>
					      <td><a href='excluir_cli.php?id=".$linha['cli_id']."'><img src='../img/delete.png'></a></td>
					      <td><a href='editarcli.php?id=".$linha['cli_id']."&cli_nome=".$linha['cli_nome']."&cli_email=".$linha['cli_email']."'><img src='../img/edit.png'></a></td>
					    </tr>
					  </tbody>
					</table>";
				}?>
				</div>
			</div>
			<div class="col-md-3">
				<br>
				<h1>Cadastro clientes:</h1>
				<br>
				<form method="POST" action="#">
					<input type="text" name="cli_nome" class="form-control" placeholder="Nome do Cliente">
					<br>
					<input type="email" name="cli_email" class="form-control" placeholder="Email do Cliente">
					<br>
					<button class="btn" type="submit" name="bt_cli_cad">Cadastrar Cliente</button>
				</form>
				<br>
				<br>
				<div style="text-align: center">
					<a href="logado.php"><button class="btn" type="submit">Voltar</button></a>
				</div>
				<?php
					if (isset($_POST['bt_cli_cad'])) {
						include "salvar_cli.php";
						echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=#'>";
					}
				?>
			</div>
		</div>
	</div>

	
<!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    </div>
  </div>
</div>
</body>
</html>

