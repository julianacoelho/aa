<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$base = "banc_trab";

	$conexao = mysqli_connect($servidor, $usuario, $senha, $base);
?>
