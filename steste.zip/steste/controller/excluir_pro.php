<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
	 <!-- The Modal -->
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Tem certeza que deseja excluir este produto?</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <form method="POST">
        	<button type="submit" class="btn" data-dismiss="modal" name="bt_voltar">Voltar</button>
        </form>
        <form method="POST">
        	<button type="submit" class="btn btn-danger" name="bt_ex_pro">Excluir</button>
        </form>
      </div>

      <!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

</body>
</html>

<?php

if (isset($_POST['bt_ex_pro'])) {
	include "conexao.php";
	$id = $_GET['id'];

	$sql = "DELETE FROM tb_produto where pro_id = $id";
	$executar = mysqli_query($conexao, $sql);

	header('Location: logado_pro.php');
}
elseif (isset($_POST['bt_voltar'])) {
	header('Location: logado_pro.php');
}

 ?>