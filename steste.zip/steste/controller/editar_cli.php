<?php
  $id = $_POST['cli_id'];
  $cli_nome = $_POST['cli_nome'];
  $cli_email = $_POST['cli_email'];

  include "conexao.php";

  $sql = "UPDATE tb_cliente SET cli_nome = '$cli_nome', cli_email = '$cli_email' where cli_id = $id";
  $executar = mysqli_query($conexao, $sql);

  header("location: logado_cli.php");
?>

