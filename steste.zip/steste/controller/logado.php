<?php
	include('verificar.php')
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logado</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
	<div class="container">
		<br>
			<br>
			<br>
		<div class="row">
			<div class="col-md-3">
				<button><a href="logado_cli.php" class="btn btn-lg">Área de clientes</a></button>
			</div>
			<div class="col-md-3">
				<button><a href="logado_vend.php" class="btn btn-lg">Área de vendedores</a></button>
			</div>
			<div class="col-md-3">
				<button><a href="logado_pro.php" class="btn btn-lg">Área de produtos</a></button>
			</div>
			<div class="col-md-3">
				<form method="POST" action="sair.php">
					<button class="btn btn-lg" name="sair" type="submit">Sair</button>
				</form>
			</div>
		</div>
		<br>
		<br>
		<br>
	</div>

	
<!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    </div>
  </div>
</div>
</body>
</html>

