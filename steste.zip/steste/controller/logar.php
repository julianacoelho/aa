<?php
	session_start();
	$senha = $_POST['senha'];
	$nome = $_POST['nome'];

	$nomeSIS = "admin";
	$senhaSIS = "admin";

	if($senha == $senhaSIS && $nome == $nomeSIS){
		$_SESSION['nome'] = $nome;
		$_SESSION['senha'] = $senha;
		header('location:logado.php');
	}else{
		header('location:../index.php');
	}
?>