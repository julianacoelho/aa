<?php
  $id = $_GET['id'];
  $vend_nome = $_GET['vend_nome'];
  $vend_email = $_GET['vend_email'];
  $vend_sessao = $_GET['vend_sessao'];
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
   <!-- The Modal -->
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Tem certeza que deseja editar este Vendedor?</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <form method='POST' action='editar_vend.php'>
          <?php
            echo "<input type='text' name='vend_nome' class='form-control' value='".$vend_nome."'>
          <input type='email' name='vend_email' class='form-control' value='".$vend_email."'>
          <input type='number' name='vend_sessao' class='form-control' value='".$vend_sessao."'>";
          ?>
          <?php echo "<input type='number' name='vend_id' class='form-control' value='".$id."' hidden>";?>
          <br>
          <button class=" btn btn-danger" type="submit">Editar</button>
        </form>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn" data-dismiss="modal" name="bt_voltar">Voltar</button>
      </div>

      <!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

</body>
</html>


