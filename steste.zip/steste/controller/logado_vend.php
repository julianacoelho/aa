<?php

	include('verificar.php')
?>
<!DOCTYPE html>
<html>
<head>
	<title>Vendedor</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h1>Vendedores</h1>
				<div  id="pesq" style="height:500px; overflow-y:scroll; overflow-x:hidden;">
					<br>
				  	<?php
				  	include 'conexao.php';

				  	$sql = "SELECT * FROM tb_vendedor;";

					$executar = mysqli_query($conexao, $sql);

				while ($linha = $executar->fetch_assoc()) {
					
				   echo "<table class='table table-light'>
				   	<thead>
					    <tr>
					      <th scope='col' >ID</th>
					      <th scope='col'>Nome</th>
					      <th scope='col'>Email</th>
					      <th scope='col'>Sessão</th>
					    </tr>
					 </thead>
					  <tbody>
					    <tr>
					      <th>".$linha['vend_id']."</th>
					      <td>".$linha['vend_nome']."</td>
					      <td>".$linha['vend_email']."</td>
					      <td>".$linha['vend_sessao']."</td>
					      <td><a href='excluir_vend.php?id=".$linha['vend_id']."'><img src='../img/delete.png'></a></td>
					      <td><a href='editarvend.php?id=".$linha['vend_id']."&vend_nome=".$linha['vend_nome']."&vend_email=".$linha['vend_email']."&vend_sessao=".$linha['vend_sessao']."'><img src='../img/edit.png'></a></td>
					    </tr>
					  </tbody>
					</table>";
				}?>

				</div>
			</div>
			<div class="col-md-3">
				<br>
				<h1>Cadastro Vendedores:</h1>
				<br>
				<form method="POST" action="#">
					<input type="text" name="vend_nome" class="form-control" placeholder="Nome do vendedor">
					<br>
					<input type="email" name="vend_email" class="form-control" placeholder="Email do vendedor">
					<br>
					<input type="number" name="vend_sessao" class="form-control" placeholder="Sessão do Vendedor">
					<br>
					<button class="btn" type="submit" name="bt_vend_cad">Cadastrar Vendedor</button>
				</form>
				<br>
				<br>
				<div style="text-align: center">
					<a href="logado.php"><button class="btn" type="submit">Voltar</button></a>
				</div>
				<?php
					if (isset($_POST['bt_vend_cad'])) {
						include "salvar_vend.php";
						echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=#'>";
					}
				?>
			</div>
		</div>


		

	</div>

	
<!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    </div>
  </div>
</div>
</body>
</html>