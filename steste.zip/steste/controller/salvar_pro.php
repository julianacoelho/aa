<?php
include "conexao.php";
$pro_nome = $_POST['pro_nome'];
$pro_preco = $_POST['pro_preco'];

$sql = "INSERT INTO tb_produto (pro_nome, pro_preco) VALUES ('$pro_nome', '$pro_preco')";

$executar = mysqli_query($conexao, $sql);
	?>
		<!DOCTYPE html>
		<html>
		<head>
			<title></title>
		</head>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/estilo.css">
		<body>
			 <br>
			 <br>
			 <div class="alert alert-success alert-dismissible fade show" role="alert">
			  <strong>Produto cadastrado com sucesso!</strong>
			  <form method="POST" action="#">
			  	 <button type="submit" class="close"  aria-label="Close" name="bt_alert">
				  <span aria-hidden="true">x</span>
				 </button>
			  </form>
			</div>

			  <!-- Bootstrap core JavaScript -->
			    <script src="../vendor/jquery/jquery.min.js"></script>
			    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

			    <!-- Plugin JavaScript -->
			    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
		</body>
		</html>
 ?>