<?php
  $id = $_POST['vend_id'];
  $vend_nome = $_POST['vend_nome'];
  $vend_email = $_POST['vend_email'];
  $vend_sessao = $_POST['vend_sessao'];

  include "conexao.php";

  $sql = "UPDATE tb_vendedor SET vend_nome = '$vend_nome', vend_email = '$vend_email', vend_sessao = '$vend_sessao' where vend_id = $id";

  $executar = mysqli_query($conexao, $sql);

  header("location: logado_vend.php");
?>

