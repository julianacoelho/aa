<?php

	include('verificar.php')
?>
<!DOCTYPE html>
<html>
<head>
	<title>Produtos</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h1>Produtos</h1>
				<div  id="pesq" style="height:500px; overflow-y:scroll; overflow-x:hidden;">
					<br>
				  	<?php
				  	include 'conexao.php';

				  	$sql = "SELECT * FROM tb_produto;";

					$executar = mysqli_query($conexao, $sql);

				while ($linha = $executar->fetch_assoc()) {
					
				   echo "<table class='table table-light'>
				   	<thead>
					    <tr>
					      <th scope='col' >ID</th>
					      <th scope='col'>Nome</th>
					      <th scope='col'>Preço</th>
					    </tr>
					 </thead>
					  <tbody>
					    <tr>
					      <th>".$linha['pro_id']."</th>
					      <td>".$linha['pro_nome']."</td>
					      <td>".$linha['pro_preco']."</td>
					      <td><a href='excluir_pro.php?id=".$linha['pro_id']."'><img src='../img/delete.png'></a></td>
					      <td><a href='editarpro.php?id=".$linha['pro_id']."&pro_nome=".$linha['pro_nome']."&pro_preco=".$linha['pro_preco']."'><img src='../img/edit.png'></a></td>
					    </tr>
					  </tbody>
					</table>";
				}?>

				</div>
			</div>
			<div class="col-md-3">
				<br>
				<h1>Cadastro Produtos:</h1>
				<br>
				<form method="POST" action="#">
					<input type="text" name="pro_nome" class="form-control" placeholder="Nome do Produto">
					<br>
					<input type="number" name="pro_preco" class="form-control" placeholder="Preço do Produto">
					<br>
					<button class="btn" type="submit" name="bt_pro_cad">Cadastrar Produto</button>
				</form>
				<br>
				<br>
				<div style="text-align: center">
					<a href="logado.php"><button class="btn" type="submit">Voltar</button></a>
				</div>
				<?php
					if (isset($_POST['bt_pro_cad'])) {
						include "salvar_pro.php";
						echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=#'>";
					}
				?>
			</div>
		</div>


		

	</div>

	
<!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    </div>
  </div>
</div>
</body>
</html>

