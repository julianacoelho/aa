<?php
session_start();
	if($_SESSION['nome'] == "admin" && $_SESSION['senha'] == "admin"){

	}else{
		header('location:../index.php');
	}
?>