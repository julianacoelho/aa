<?php
	if(isset($_POST['sair'])){
		$_SESSION['nome'] = array();
		$_SESSION['senha'] = array();

		session_destroy();

		header('location:../index.php');
	}
?>