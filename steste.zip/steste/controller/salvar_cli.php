<?php
include "conexao.php";
$cli_nome = $_POST['cli_nome'];
$cli_email = $_POST['cli_email'];

$sql = "INSERT INTO tb_cliente (cli_nome, cli_email) VALUES ('$cli_nome', '$cli_email')";

$executar = mysqli_query($conexao, $sql);
	?>
		<!DOCTYPE html>
		<html>
		<head>
			<title></title>
		</head>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/estilo.css">
		<body>
			 <br>
			 <br>
			 <div class="alert alert-success alert-dismissible fade show" role="alert">
			  <strong>Cliente cadastrado com sucesso!</strong>
			  <form method="POST" action="#">
			  	 <button type="submit" class="close"  aria-label="Close" name="bt_alert">
				  <span aria-hidden="true">x</span>
				 </button>
			  </form>
			</div>

			  <!-- Bootstrap core JavaScript -->
			    <script src="../vendor/jquery/jquery.min.js"></script>
			    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

			    <!-- Plugin JavaScript -->
			    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
		</body>
		</html>
 ?>