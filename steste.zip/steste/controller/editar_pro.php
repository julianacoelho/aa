<?php
  $id = $_POST['pro_id'];
  $pro_nome = $_POST['pro_nome'];
  $pro_preco = $_POST['pro_preco'];

  include "conexao.php";

  $sql = "UPDATE tb_produto SET pro_nome = '$pro_nome', pro_preco = '$pro_preco' where pro_id = $id";
  $executar = mysqli_query($conexao, $sql);

  header("location: logado_pro.php");
?>

